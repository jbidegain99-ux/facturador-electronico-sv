"use strict";(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[3774],{4958:function(e,t,n){n.d(t,{Z:function(){return r}});/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,n(8525).Z)("AlertTriangle",[["path",{d:"m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z",key:"c3ski4"}],["path",{d:"M12 9v4",key:"juzpu7"}],["path",{d:"M12 17h.01",key:"p32p05"}]])},7418:function(e,t,n){n.d(t,{Z:function(){return r}});/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,n(8525).Z)("ArrowLeft",[["path",{d:"m12 19-7-7 7-7",key:"1l729n"}],["path",{d:"M19 12H5",key:"x3x0zl"}]])},4805:function(e,t,n){n.d(t,{Z:function(){return r}});/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,n(8525).Z)("Building2",[["path",{d:"M6 22V4a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v18Z",key:"1b4qmf"}],["path",{d:"M6 12H4a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h2",key:"i71pzd"}],["path",{d:"M18 9h2a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2h-2",key:"10jefs"}],["path",{d:"M10 6h4",key:"1itunk"}],["path",{d:"M10 10h4",key:"tcdvrf"}],["path",{d:"M10 14h4",key:"kelpxr"}],["path",{d:"M10 18h4",key:"1ulq68"}]])},7045:function(e,t,n){n.d(t,{Z:function(){return r}});/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,n(8525).Z)("Calculator",[["rect",{width:"16",height:"20",x:"4",y:"2",rx:"2",key:"1nb95v"}],["line",{x1:"8",x2:"16",y1:"6",y2:"6",key:"x4nwl0"}],["line",{x1:"16",x2:"16",y1:"14",y2:"18",key:"wjye3r"}],["path",{d:"M16 10h.01",key:"1m94wz"}],["path",{d:"M12 10h.01",key:"1nrarc"}],["path",{d:"M8 10h.01",key:"19clt8"}],["path",{d:"M12 14h.01",key:"1etili"}],["path",{d:"M8 14h.01",key:"6423bh"}],["path",{d:"M12 18h.01",key:"mhygvu"}],["path",{d:"M8 18h.01",key:"lrp35t"}]])},3385:function(e,t,n){n.d(t,{Z:function(){return r}});/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,n(8525).Z)("Calendar",[["rect",{width:"18",height:"18",x:"3",y:"4",rx:"2",ry:"2",key:"eu3xkr"}],["line",{x1:"16",x2:"16",y1:"2",y2:"6",key:"m3sa8f"}],["line",{x1:"8",x2:"8",y1:"2",y2:"6",key:"18kwsl"}],["line",{x1:"3",x2:"21",y1:"10",y2:"10",key:"xt86sb"}]])},8589:function(e,t,n){n.d(t,{Z:function(){return r}});/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,n(8525).Z)("CheckCircle2",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"m9 12 2 2 4-4",key:"dzmm74"}]])},8610:function(e,t,n){n.d(t,{Z:function(){return r}});/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,n(8525).Z)("CheckCircle",[["path",{d:"M22 11.08V12a10 10 0 1 1-5.93-9.14",key:"g774vq"}],["path",{d:"m9 11 3 3L22 4",key:"1pflzl"}]])},6048:function(e,t,n){n.d(t,{Z:function(){return r}});/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,n(8525).Z)("Clock",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["polyline",{points:"12 6 12 12 16 14",key:"68esgv"}]])},4303:function(e,t,n){n.d(t,{Z:function(){return r}});/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,n(8525).Z)("Eye",[["path",{d:"M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z",key:"rwhkz3"}],["circle",{cx:"12",cy:"12",r:"3",key:"1v7zrd"}]])},8652:function(e,t,n){n.d(t,{Z:function(){return r}});/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,n(8525).Z)("FileText",[["path",{d:"M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z",key:"1rqfz7"}],["path",{d:"M14 2v4a2 2 0 0 0 2 2h4",key:"tnqrlb"}],["path",{d:"M10 9H8",key:"b1mrlr"}],["path",{d:"M16 13H8",key:"t4e002"}],["path",{d:"M16 17H8",key:"z1uh3a"}]])},6631:function(e,t,n){n.d(t,{Z:function(){return r}});/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,n(8525).Z)("Files",[["path",{d:"M20 7h-3a2 2 0 0 1-2-2V2",key:"x099mo"}],["path",{d:"M9 18a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h7l4 4v10a2 2 0 0 1-2 2Z",key:"18t6ie"}],["path",{d:"M3 7.6v12.8A1.6 1.6 0 0 0 4.6 22h9.8",key:"1nja0z"}]])},8554:function(e,t,n){n.d(t,{Z:function(){return r}});/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,n(8525).Z)("Hash",[["line",{x1:"4",x2:"20",y1:"9",y2:"9",key:"4lhtct"}],["line",{x1:"4",x2:"20",y1:"15",y2:"15",key:"vyu0kd"}],["line",{x1:"10",x2:"8",y1:"3",y2:"21",key:"1ggp8o"}],["line",{x1:"16",x2:"14",y1:"3",y2:"21",key:"weycgp"}]])},1663:function(e,t,n){n.d(t,{Z:function(){return r}});/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,n(8525).Z)("Info",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"M12 16v-4",key:"1dtifu"}],["path",{d:"M12 8h.01",key:"e9boi3"}]])},6766:function(e,t,n){n.d(t,{Z:function(){return r}});/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,n(8525).Z)("Keyboard",[["rect",{width:"20",height:"16",x:"2",y:"4",rx:"2",ry:"2",key:"15u882"}],["path",{d:"M6 8h.001",key:"1ej0i3"}],["path",{d:"M10 8h.001",key:"1x2st2"}],["path",{d:"M14 8h.001",key:"1vkmyp"}],["path",{d:"M18 8h.001",key:"kfsenl"}],["path",{d:"M8 12h.001",key:"1sjpby"}],["path",{d:"M12 12h.001",key:"al75ts"}],["path",{d:"M16 12h.001",key:"931bgk"}],["path",{d:"M7 16h10",key:"wp8him"}]])},9420:function(e,t,n){n.d(t,{Z:function(){return r}});/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,n(8525).Z)("Loader2",[["path",{d:"M21 12a9 9 0 1 1-6.219-8.56",key:"13zald"}]])},3971:function(e,t,n){n.d(t,{Z:function(){return r}});/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,n(8525).Z)("Package",[["path",{d:"m7.5 4.27 9 5.15",key:"1c824w"}],["path",{d:"M21 8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16Z",key:"hh9hay"}],["path",{d:"m3.3 7 8.7 5 8.7-5",key:"g66t2b"}],["path",{d:"M12 22V12",key:"d0xqtd"}]])},2725:function(e,t,n){n.d(t,{Z:function(){return r}});/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,n(8525).Z)("Plus",[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"M12 5v14",key:"s699le"}]])},7481:function(e,t,n){n.d(t,{Z:function(){return r}});/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,n(8525).Z)("Save",[["path",{d:"M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z",key:"1owoqh"}],["polyline",{points:"17 21 17 13 7 13 7 21",key:"1md35c"}],["polyline",{points:"7 3 7 8 15 8",key:"8nz8an"}]])},8487:function(e,t,n){n.d(t,{Z:function(){return r}});/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,n(8525).Z)("Search",[["circle",{cx:"11",cy:"11",r:"8",key:"4ej97u"}],["path",{d:"m21 21-4.3-4.3",key:"1qie3q"}]])},1792:function(e,t,n){n.d(t,{Z:function(){return r}});/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,n(8525).Z)("Send",[["path",{d:"m22 2-7 20-4-9-9-4Z",key:"1q3vgg"}],["path",{d:"M22 2 11 13",key:"nzbqef"}]])},5518:function(e,t,n){n.d(t,{Z:function(){return r}});/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,n(8525).Z)("Sparkles",[["path",{d:"m12 3-1.912 5.813a2 2 0 0 1-1.275 1.275L3 12l5.813 1.912a2 2 0 0 1 1.275 1.275L12 21l1.912-5.813a2 2 0 0 1 1.275-1.275L21 12l-5.813-1.912a2 2 0 0 1-1.275-1.275L12 3Z",key:"17u4zn"}],["path",{d:"M5 3v4",key:"bklmnn"}],["path",{d:"M19 17v4",key:"iiml17"}],["path",{d:"M3 5h4",key:"nem4j1"}],["path",{d:"M17 19h4",key:"lbex7p"}]])},3223:function(e,t,n){n.d(t,{Z:function(){return r}});/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,n(8525).Z)("Star",[["polygon",{points:"12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2",key:"8f66p6"}]])},2944:function(e,t,n){n.d(t,{Z:function(){return r}});/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,n(8525).Z)("Trash2",[["path",{d:"M3 6h18",key:"d0wm0j"}],["path",{d:"M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6",key:"4alrt4"}],["path",{d:"M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2",key:"v07s0e"}],["line",{x1:"10",x2:"10",y1:"11",y2:"17",key:"1uufr5"}],["line",{x1:"14",x2:"14",y1:"11",y2:"17",key:"xtxkd"}]])},7380:function(e,t,n){n.d(t,{Z:function(){return r}});/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,n(8525).Z)("UserPlus",[["path",{d:"M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2",key:"1yyitq"}],["circle",{cx:"9",cy:"7",r:"4",key:"nufk8"}],["line",{x1:"19",x2:"19",y1:"8",y2:"14",key:"1bvyxn"}],["line",{x1:"22",x2:"16",y1:"11",y2:"11",key:"1shjgl"}]])},2987:function(e,t,n){n.d(t,{Z:function(){return r}});/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,n(8525).Z)("User",[["path",{d:"M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2",key:"975kel"}],["circle",{cx:"12",cy:"7",r:"4",key:"17ys0d"}]])},1025:function(e,t,n){n.d(t,{Z:function(){return r}});/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,n(8525).Z)("X",[["path",{d:"M18 6 6 18",key:"1bl5f8"}],["path",{d:"m6 6 12 12",key:"d8bk6v"}]])},1068:function(e,t,n){n.d(t,{Z:function(){return r}});/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,n(8525).Z)("Zap",[["polygon",{points:"13 2 3 14 12 14 11 22 21 10 12 10 13 2",key:"45s27k"}]])},8598:function(e,t,n){n.d(t,{fC:function(){return m},z$:function(){return g}});var r=n(6655),a=n(7767),i=n(8257),l=n(1308),d=n(6495),c=n(5604),u=n(2125),y=n(2405),o=n(855),h=n(1674),k="Checkbox",[p,f]=(0,i.b)(k),[s,x]=p(k);function Z(e){let{__scopeCheckbox:t,checked:n,children:a,defaultChecked:i,disabled:l,form:c,name:u,onCheckedChange:y,required:o,value:p="on",internal_do_not_use_render:f}=e,[x,Z]=(0,d.T)({prop:n,defaultProp:null!=i&&i,onChange:y,caller:k}),[v,M]=r.useState(null),[m,b]=r.useState(null),g=r.useRef(!1),w=!v||!!c||!!v.closest("form"),j={checked:x,disabled:l,setChecked:Z,control:v,setControl:M,name:u,form:c,value:p,hasConsumerStoppedPropagationRef:g,required:o,defaultChecked:!z(i)&&i,isFormControl:w,bubbleInput:m,setBubbleInput:b};return(0,h.jsx)(s,{scope:t,...j,children:"function"==typeof f?f(j):a})}var v="CheckboxTrigger",M=r.forwardRef((e,t)=>{let{__scopeCheckbox:n,onKeyDown:i,onClick:d,...c}=e,{control:u,value:y,disabled:k,checked:p,required:f,setControl:s,setChecked:Z,hasConsumerStoppedPropagationRef:M,isFormControl:m,bubbleInput:b}=x(v,n),g=(0,a.e)(t,s),w=r.useRef(p);return r.useEffect(()=>{let e=null==u?void 0:u.form;if(e){let t=()=>Z(w.current);return e.addEventListener("reset",t),()=>e.removeEventListener("reset",t)}},[u,Z]),(0,h.jsx)(o.WV.button,{type:"button",role:"checkbox","aria-checked":z(p)?"mixed":p,"aria-required":f,"data-state":C(p),"data-disabled":k?"":void 0,disabled:k,value:y,...c,ref:g,onKeyDown:(0,l.Mj)(i,e=>{"Enter"===e.key&&e.preventDefault()}),onClick:(0,l.Mj)(d,e=>{Z(e=>!!z(e)||!e),b&&m&&(M.current=e.isPropagationStopped(),M.current||e.stopPropagation())})})});M.displayName=v;var m=r.forwardRef((e,t)=>{let{__scopeCheckbox:n,name:r,checked:a,defaultChecked:i,required:l,disabled:d,value:c,onCheckedChange:u,form:y,...o}=e;return(0,h.jsx)(Z,{__scopeCheckbox:n,checked:a,defaultChecked:i,disabled:d,required:l,onCheckedChange:u,name:r,form:y,value:c,internal_do_not_use_render:e=>{let{isFormControl:r}=e;return(0,h.jsxs)(h.Fragment,{children:[(0,h.jsx)(M,{...o,ref:t,__scopeCheckbox:n}),r&&(0,h.jsx)(j,{__scopeCheckbox:n})]})}})});m.displayName=k;var b="CheckboxIndicator",g=r.forwardRef((e,t)=>{let{__scopeCheckbox:n,forceMount:r,...a}=e,i=x(b,n);return(0,h.jsx)(y.z,{present:r||z(i.checked)||!0===i.checked,children:(0,h.jsx)(o.WV.span,{"data-state":C(i.checked),"data-disabled":i.disabled?"":void 0,...a,ref:t,style:{pointerEvents:"none",...e.style}})})});g.displayName=b;var w="CheckboxBubbleInput",j=r.forwardRef((e,t)=>{let{__scopeCheckbox:n,...i}=e,{control:l,hasConsumerStoppedPropagationRef:d,checked:y,defaultChecked:k,required:p,disabled:f,name:s,value:Z,form:v,bubbleInput:M,setBubbleInput:m}=x(w,n),b=(0,a.e)(t,m),g=(0,c.D)(y),j=(0,u.t)(l);r.useEffect(()=>{if(!M)return;let e=Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype,"checked").set,t=!d.current;if(g!==y&&e){let n=new Event("click",{bubbles:t});M.indeterminate=z(y),e.call(M,!z(y)&&y),M.dispatchEvent(n)}},[M,g,y,d]);let C=r.useRef(!z(y)&&y);return(0,h.jsx)(o.WV.input,{type:"checkbox","aria-hidden":!0,defaultChecked:null!=k?k:C.current,required:p,disabled:f,name:s,value:Z,form:v,...i,tabIndex:-1,ref:b,style:{...i.style,...j,position:"absolute",pointerEvents:"none",opacity:0,margin:0,transform:"translateX(-100%)"}})});function z(e){return"indeterminate"===e}function C(e){return z(e)?"indeterminate":e?"checked":"unchecked"}j.displayName=w},7448:function(e,t,n){n.d(t,{f:function(){return c}});var r=n(6655);n(6859);var a=n(5511),i=n(1674),l=["a","button","div","form","h2","h3","img","input","label","li","nav","ol","p","select","span","svg","ul"].reduce((e,t)=>{let n=(0,a.Z8)("Primitive.".concat(t)),l=r.forwardRef((e,r)=>{let{asChild:a,...l}=e,d=a?n:t;return window[Symbol.for("radix-ui")]=!0,(0,i.jsx)(d,{...l,ref:r})});return l.displayName="Primitive.".concat(t),{...e,[t]:l}},{}),d=r.forwardRef((e,t)=>(0,i.jsx)(l.label,{...e,ref:t,onMouseDown:t=>{var n;t.target.closest("button, input, select, textarea")||(null===(n=e.onMouseDown)||void 0===n||n.call(e,t),!t.defaultPrevented&&t.detail>1&&t.preventDefault())}}));d.displayName="Label";var c=d}}]);