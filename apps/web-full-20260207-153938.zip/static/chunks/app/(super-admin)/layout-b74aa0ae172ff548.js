(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[4254],{9768:function(e,t,a){Promise.resolve().then(a.bind(a,9965))},8525:function(e,t,a){"use strict";a.d(t,{Z:function(){return i}});var n=a(6655),r={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:2,strokeLinecap:"round",strokeLinejoin:"round"};/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let s=e=>e.replace(/([a-z0-9])([A-Z])/g,"$1-$2").toLowerCase().trim(),i=(e,t)=>{let a=(0,n.forwardRef)((a,i)=>{let{color:c="currentColor",size:l=24,strokeWidth:o=2,absoluteStrokeWidth:d,className:u="",children:h,...m}=a;return(0,n.createElement)("svg",{ref:i,...r,width:l,height:l,stroke:c,strokeWidth:d?24*Number(o)/Number(l):o,className:["lucide","lucide-".concat(s(e)),u].join(" "),...m},[...t.map(e=>{let[t,a]=e;return(0,n.createElement)(t,a)}),...Array.isArray(h)?h:[h]])});return a.displayName="".concat(e),a}},8475:function(e,t,a){"use strict";a.d(t,{Z:function(){return n}});/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let n=(0,a(8525).Z)("Bell",[["path",{d:"M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9",key:"1qo2s2"}],["path",{d:"M10.3 21a1.94 1.94 0 0 0 3.4 0",key:"qgo35s"}]])},4805:function(e,t,a){"use strict";a.d(t,{Z:function(){return n}});/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let n=(0,a(8525).Z)("Building2",[["path",{d:"M6 22V4a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v18Z",key:"1b4qmf"}],["path",{d:"M6 12H4a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h2",key:"i71pzd"}],["path",{d:"M18 9h2a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2h-2",key:"10jefs"}],["path",{d:"M10 6h4",key:"1itunk"}],["path",{d:"M10 10h4",key:"tcdvrf"}],["path",{d:"M10 14h4",key:"kelpxr"}],["path",{d:"M10 18h4",key:"1ulq68"}]])},5019:function(e,t,a){"use strict";a.d(t,{Z:function(){return n}});/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let n=(0,a(8525).Z)("ChevronDown",[["path",{d:"m6 9 6 6 6-6",key:"qrunsl"}]])},4565:function(e,t,a){"use strict";a.d(t,{Z:function(){return n}});/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let n=(0,a(8525).Z)("CreditCard",[["rect",{width:"20",height:"14",x:"2",y:"5",rx:"2",key:"ynyp8z"}],["line",{x1:"2",x2:"22",y1:"10",y2:"10",key:"1b3vmo"}]])},6866:function(e,t,a){"use strict";a.d(t,{Z:function(){return n}});/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let n=(0,a(8525).Z)("Database",[["ellipse",{cx:"12",cy:"5",rx:"9",ry:"3",key:"msslwz"}],["path",{d:"M3 5V19A9 3 0 0 0 21 19V5",key:"1wlel7"}],["path",{d:"M3 12A9 3 0 0 0 21 12",key:"mv7ke4"}]])},8652:function(e,t,a){"use strict";a.d(t,{Z:function(){return n}});/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let n=(0,a(8525).Z)("FileText",[["path",{d:"M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z",key:"1rqfz7"}],["path",{d:"M14 2v4a2 2 0 0 0 2 2h4",key:"tnqrlb"}],["path",{d:"M10 9H8",key:"b1mrlr"}],["path",{d:"M16 13H8",key:"t4e002"}],["path",{d:"M16 17H8",key:"z1uh3a"}]])},6791:function(e,t,a){"use strict";a.d(t,{Z:function(){return n}});/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let n=(0,a(8525).Z)("HardDrive",[["line",{x1:"22",x2:"2",y1:"12",y2:"12",key:"1y58io"}],["path",{d:"M5.45 5.11 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z",key:"oot6mr"}],["line",{x1:"6",x2:"6.01",y1:"16",y2:"16",key:"sgf278"}],["line",{x1:"10",x2:"10.01",y1:"16",y2:"16",key:"1l4acy"}]])},8079:function(e,t,a){"use strict";a.d(t,{Z:function(){return n}});/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let n=(0,a(8525).Z)("LayoutDashboard",[["rect",{width:"7",height:"9",x:"3",y:"3",rx:"1",key:"10lvy0"}],["rect",{width:"7",height:"5",x:"14",y:"3",rx:"1",key:"16une8"}],["rect",{width:"7",height:"9",x:"14",y:"12",rx:"1",key:"1hutg5"}],["rect",{width:"7",height:"5",x:"3",y:"16",rx:"1",key:"ldoo1y"}]])},9420:function(e,t,a){"use strict";a.d(t,{Z:function(){return n}});/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let n=(0,a(8525).Z)("Loader2",[["path",{d:"M21 12a9 9 0 1 1-6.219-8.56",key:"13zald"}]])},4742:function(e,t,a){"use strict";a.d(t,{Z:function(){return n}});/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let n=(0,a(8525).Z)("LogOut",[["path",{d:"M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4",key:"1uf3rs"}],["polyline",{points:"16 17 21 12 16 7",key:"1gabdz"}],["line",{x1:"21",x2:"9",y1:"12",y2:"12",key:"1uyos4"}]])},5732:function(e,t,a){"use strict";a.d(t,{Z:function(){return n}});/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let n=(0,a(8525).Z)("ScrollText",[["path",{d:"M8 21h12a2 2 0 0 0 2-2v-2H10v2a2 2 0 1 1-4 0V5a2 2 0 1 0-4 0v3h4",key:"13a6an"}],["path",{d:"M19 17V5a2 2 0 0 0-2-2H4",key:"zz82l3"}],["path",{d:"M15 8h-5",key:"1khuty"}],["path",{d:"M15 12h-5",key:"r7krc0"}]])},5835:function(e,t,a){"use strict";a.d(t,{Z:function(){return n}});/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let n=(0,a(8525).Z)("Settings",[["path",{d:"M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z",key:"1qme2f"}],["circle",{cx:"12",cy:"12",r:"3",key:"1v7zrd"}]])},5024:function(e,t,a){"use strict";a.d(t,{Z:function(){return n}});/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let n=(0,a(8525).Z)("Ticket",[["path",{d:"M2 9a3 3 0 0 1 0 6v2a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-2a3 3 0 0 1 0-6V7a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2Z",key:"qn84l0"}],["path",{d:"M13 5v2",key:"dyzc3o"}],["path",{d:"M13 17v2",key:"1ont0d"}],["path",{d:"M13 11v2",key:"1wjjxi"}]])},7542:function(e,t,a){"use strict";a.d(t,{Z:function(){return n}});/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let n=(0,a(8525).Z)("Users",[["path",{d:"M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2",key:"1yyitq"}],["circle",{cx:"9",cy:"7",r:"4",key:"nufk8"}],["path",{d:"M22 21v-2a4 4 0 0 0-3-3.87",key:"kshegd"}],["path",{d:"M16 3.13a4 4 0 0 1 0 7.75",key:"1da9ce"}]])},4483:function(e,t,a){"use strict";a.d(t,{Z:function(){return n}});/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let n=(0,a(8525).Z)("Webhook",[["path",{d:"M18 16.98h-5.99c-1.1 0-1.95.94-2.48 1.9A4 4 0 0 1 2 17c.01-.7.2-1.4.57-2",key:"q3hayz"}],["path",{d:"m6 17 3.13-5.78c.53-.97.1-2.18-.5-3.1a4 4 0 1 1 6.89-4.06",key:"1go1hn"}],["path",{d:"m12 6 3.13 5.73C15.66 12.7 16.9 13 18 13a4 4 0 0 1 0 8",key:"qlwsc0"}]])},1025:function(e,t,a){"use strict";a.d(t,{Z:function(){return n}});/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let n=(0,a(8525).Z)("X",[["path",{d:"M18 6 6 18",key:"1bl5f8"}],["path",{d:"m6 6 12 12",key:"d8bk6v"}]])},9965:function(e,t,a){"use strict";a.r(t),a.d(t,{default:function(){return N}});var n=a(1674),r=a(6655),s=a(7997),i=a(4603),c=a(8079),l=a(4805),o=a(5024),d=a(6866),u=a(4565),h=a(8475),m=a(5732),f=a(6791),y=a(4483),x=a(7542),p=a(5835),k=a(9420),v=a(8652),g=a(1025),Z=a(4742);/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let b=(0,a(8525).Z)("Menu",[["line",{x1:"4",x2:"20",y1:"12",y2:"12",key:"1e0a9i"}],["line",{x1:"4",x2:"20",y1:"6",y2:"6",key:"1owob3"}],["line",{x1:"4",x2:"20",y1:"18",y2:"18",key:"yk5zj1"}]]);var j=a(5019);let w=[{name:"Dashboard",href:"/admin",icon:c.Z},{name:"Empresas",href:"/admin/tenants",icon:l.Z},{name:"Soporte",href:"/admin/support",icon:o.Z},{name:"Catalogos",href:"/admin/catalogos",icon:d.Z},{name:"Planes",href:"/admin/planes",icon:u.Z},{name:"Notificaciones",href:"/admin/notificaciones",icon:h.Z},{name:"Logs",href:"/admin/logs",icon:m.Z},{name:"Backups",href:"/admin/backups",icon:f.Z},{name:"Webhooks",href:"/admin/webhooks",icon:y.Z},{name:"Administradores",href:"/admin/admins",icon:x.Z},{name:"Configuracion",href:"/admin/settings",icon:p.Z}];function N(e){var t;let{children:a}=e,c=(0,i.usePathname)(),l=(0,i.useRouter)(),[o,d]=(0,r.useState)(!1),[u,h]=(0,r.useState)(null),[m,f]=(0,r.useState)(!0);return((0,r.useEffect)(()=>{(async()=>{let e=localStorage.getItem("token");if(!e){l.push("/admin/login");return}try{let t=await fetch("".concat("http://localhost:3001/api/v1","/api/v1/auth/profile"),{headers:{Authorization:"Bearer ".concat(e)}});if(!t.ok)throw Error("Unauthorized");let a=await t.json();if("SUPER_ADMIN"!==a.rol){localStorage.removeItem("token"),l.push("/admin/login");return}h(a)}catch(e){localStorage.removeItem("token"),l.push("/admin/login");return}finally{f(!1)}})()},[l]),m)?(0,n.jsx)("div",{className:"min-h-screen flex items-center justify-center bg-background",children:(0,n.jsxs)("div",{className:"flex items-center gap-3",children:[(0,n.jsx)(k.Z,{className:"w-6 h-6 animate-spin text-primary"}),(0,n.jsx)("span",{className:"text-muted-foreground",children:"Cargando panel de administracion..."})]})}):u?(0,n.jsxs)("div",{className:"min-h-screen",children:[o&&(0,n.jsx)("div",{className:"fixed inset-0 z-40 bg-black/50 lg:hidden",onClick:()=>d(!1)}),(0,n.jsx)("aside",{className:"fixed top-0 left-0 z-50 h-full w-64 glass-card border-r border-border transform transition-transform duration-200 lg:translate-x-0 ".concat(o?"translate-x-0":"-translate-x-full"),children:(0,n.jsxs)("div",{className:"flex flex-col h-full",children:[(0,n.jsxs)("div",{className:"flex items-center justify-between p-6 border-b border-border",children:[(0,n.jsxs)("div",{className:"flex items-center gap-3",children:[(0,n.jsx)("div",{className:"w-10 h-10 rounded-lg gradient-primary flex items-center justify-center",children:(0,n.jsx)(v.Z,{className:"w-6 h-6 text-white"})}),(0,n.jsxs)("div",{children:[(0,n.jsx)("div",{className:"font-bold text-white",children:"Super Admin"}),(0,n.jsx)("div",{className:"text-xs text-muted-foreground",children:"Facturador SV"})]})]}),(0,n.jsx)("button",{className:"lg:hidden text-muted-foreground hover:text-white",onClick:()=>d(!1),children:(0,n.jsx)(g.Z,{className:"w-6 h-6"})})]}),(0,n.jsx)("nav",{className:"flex-1 p-4 space-y-2",children:w.map(e=>{let t=c===e.href||c.startsWith(e.href+"/");return(0,n.jsxs)(s.default,{href:e.href,className:"sidebar-link ".concat(t?"active":""),children:[(0,n.jsx)(e.icon,{className:"w-5 h-5"}),e.name]},e.name)})}),(0,n.jsx)("div",{className:"p-4 border-t border-border",children:(0,n.jsxs)("button",{onClick:()=>{localStorage.removeItem("token"),l.push("/admin/login")},className:"sidebar-link w-full text-red-400 hover:text-red-300 hover:bg-red-500/10",children:[(0,n.jsx)(Z.Z,{className:"w-5 h-5"}),"Cerrar Sesion"]})})]})}),(0,n.jsxs)("div",{className:"lg:pl-64",children:[(0,n.jsx)("header",{className:"sticky top-0 z-30 glass-card border-b border-border",children:(0,n.jsxs)("div",{className:"flex items-center justify-between px-6 py-4",children:[(0,n.jsx)("button",{className:"lg:hidden text-muted-foreground hover:text-white",onClick:()=>d(!0),children:(0,n.jsx)(b,{className:"w-6 h-6"})}),(0,n.jsx)("div",{className:"flex-1"}),(0,n.jsx)("div",{className:"flex items-center gap-4",children:(0,n.jsxs)("div",{className:"flex items-center gap-2 px-3 py-2 rounded-lg glass-card",children:[(0,n.jsx)("div",{className:"w-8 h-8 rounded-full gradient-primary flex items-center justify-center text-white text-sm font-medium",children:(null===(t=u.nombre)||void 0===t?void 0:t.charAt(0).toUpperCase())||"SA"}),(0,n.jsx)("span",{className:"text-sm text-white",children:u.nombre||"Super Admin"}),(0,n.jsx)(j.Z,{className:"w-4 h-4 text-muted-foreground"})]})})]})}),(0,n.jsx)("main",{className:"p-6",children:a})]})]}):null}},7997:function(e,t,a){"use strict";a.d(t,{default:function(){return r.a}});var n=a(3040),r=a.n(n)},4603:function(e,t,a){"use strict";var n=a(2988);a.o(n,"useParams")&&a.d(t,{useParams:function(){return n.useParams}}),a.o(n,"usePathname")&&a.d(t,{usePathname:function(){return n.usePathname}}),a.o(n,"useRouter")&&a.d(t,{useRouter:function(){return n.useRouter}}),a.o(n,"useSearchParams")&&a.d(t,{useSearchParams:function(){return n.useSearchParams}})}},function(e){e.O(0,[3040,1293,9997,1744],function(){return e(e.s=9768)}),_N_E=e.O()}]);