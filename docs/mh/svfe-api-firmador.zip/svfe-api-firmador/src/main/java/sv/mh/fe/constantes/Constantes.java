package sv.mh.fe.constantes;

public class Constantes {

	
	public static final String DIRECTORY_UPLOADS = System.getProperty("user.dir")+"/uploads";	
	
}
