package sv.mh.fe.constantes;

public enum TipoLlave {
	PUBLIC,
	PRIVATE
}