package sv.mh.fe.controller;

import org.springframework.beans.factory.annotation.Autowired;

import sv.mh.fe.utils.Mensaje;

public class Controller {

	@Autowired
	public Mensaje mensaje;	
		
}
