package sv.mh.fe.models.minec;

public class AuthorityKeyIdentifier {
	
	private String keyIdentifier;

	public String getKeyIdentifier() {
		return keyIdentifier;
	}

	public void setKeyIdentifier(String keyIdentifier) {
		this.keyIdentifier = keyIdentifier;
	}

	public AuthorityKeyIdentifier() {
		super();
	}
	
		
}
