package sv.mh.fe.models.minec;

public class SubjectKeyIdentifier {
	
	private String keyIdentifier;

	public SubjectKeyIdentifier() {
		super();
	}

	public String getKeyIdentifier() {
		return keyIdentifier;
	}

	public void setKeyIdentifier(String keyIdentifier) {
		this.keyIdentifier = keyIdentifier;
	}
		
}
